
public enum Pais {
	Brasil,EUA

}


public class Real implements MoedaFactory {
	
	@Override
	public String Simbolo() {
		return "R$";
	}

}


public class USDolar implements MoedaFactory{
	
	@Override
	public String Simbolo(){
		return "USD$";
	}
}

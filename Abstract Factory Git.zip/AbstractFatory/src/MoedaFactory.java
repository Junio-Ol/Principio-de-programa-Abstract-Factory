
public interface MoedaFactory {

   public String Simbolo();

}
